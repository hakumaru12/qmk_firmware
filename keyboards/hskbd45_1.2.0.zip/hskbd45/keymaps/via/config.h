#define NUM_ENCODERS_LEFT  1  // 左側エンコーダーの数
#define NUM_ENCODERS_RIGHT 1  // 右側エンコーダーの数
#define NUM_ENCODERS 2
#define ENCODER_RESOLUTION 2
#define SPLIT_ENCODERS
#define SPLIT_HAND_PIN B6
#define SOFT_SERIAL_PIN D0
#define SPLIT_TRANSPORT_MIRROR
#define MASTER_LEFT
#define RGBLIGHT_LAYERS
#define RGBLIGHT_MAX_LAYERS 4
#define LED_LAYOUT( \
    L00, L01, R00, R01\
) { \
        L01, L00, \
        \
        R00, R01 \
    }
#define RGBLIGHT_LED_MAP LED_LAYOUT( \
    0,  1,  2,  3 \
)
